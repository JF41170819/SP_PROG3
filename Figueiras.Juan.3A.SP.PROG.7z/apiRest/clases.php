<?php

    class Media{

    public $id;
    public $color;
    public $marca;
    public $precio;
    public $talle;
    
    public function __construct($id = 0, $color = "Sin color", $marca = "Sin marca", $precio = 0, $talle = "Sin talle")
    {
        $this->id = $id;
        $this->color = $color;
        $this->marca = $marca;
        $this->precio = $precio;
        $this->talle = $talle;
    }

    public static function AltaDeMedias($request, $response)
    {
        $atributos = $request->getParsedBody();

        $media = new Media(0, $atributos['color'], $atributos['marca'], $atributos['precio'], $atributos['talle']);

        $conexion = 'mysql:host=localhost;dbname=MerceriaBD;charset=utf8';
        $usuario='root';
        $clave='';

        try
        {
            $pdo = new PDO($conexion, $usuario, $clave);
            
            //Preparo la sentencia.
        
            $sentencia = $pdo->prepare('INSERT INTO medias(color, marca, precio, talle) VALUES ("'.$media->color.'","'. $media->marca.'",'.$media->precio.',"'.$media->talle.'")');
            
            //Ejecuto la sentencia.

            $retornador = $sentencia->execute();

            var_dump($retornador);

            if($retornador)
            {
                return $response->withJson((['exito' => true]));
            }
            else
            {
                return $response->withJson((['exito' => false]));
            }
        }
        catch(PDOException $e)
        {
            return $response->withJson((["excepcion" => $e->getMessage()]));
        }

    }

    public static function ListadoDeMedias($request, $response)
    {
        $conexion = 'mysql:host=localhost;dbname=MerceriaBD;charset=utf8';
        $usuario='root';
        $clave='';

        try
        {
            $arrayMedias = array();

            $pdo = new PDO($conexion, $usuario, $clave);
            
            //Preparo la sentencia.
           
            $sentencia = $pdo->prepare('SELECT * FROM medias');
            
            //Ejecuto la sentencia.

            $retornador = $sentencia->execute();

            while($fila = $sentencia->fetch(PDO::FETCH_ASSOC))
            {
                ini_set('memory_limit', '-1');

                $media = new Media($fila['id'],$fila['color'], $fila['marca'], $fila['precio'], $fila['talle']);

                array_push($arrayMedias, $media);

            }

            var_dump($retornador);

            if($retornador)
            {
                return $response->withJson(['medias' => $arrayMedias], 200);
            }
            else
            {
                return $response->withJson((['exito' => false]));
            }
        }
        catch(PDOException $e)
        {
            return $response->withJson((["excepcion" => $e->getMessage()]));
        }
    }


    public static function EliminarMedia($request, $response)
    {
        $usuario = 'root';
        $clave = '';

        $datos = $request->getParsedBody();

        $arrayUsuarios = Usuario::ListadoDeUsuarios($request, $response);
        

        /*for($j = 0; $j < count($arrayUsuario); $j++)
        {
            if($arrayUsuario[$j] == $datos['id'])
            {
                $usr = $arrayUsuario[$j];
                var_dump($usr);
                break;
            }
        }*/
        

        try 
        {
            $pdo = new PDO('mysql:host=localhost;dbname=MerceriaBD;charset=utf8', $usuario, $clave);

            $sentencia = $pdo->prepare('DELETE FROM medias WHERE `id`='. $datos['id']. "'");

            $resultado = $sentencia->execute();

            if($resultado)
            {
                return $response->withJson((["retorno" => $resultado]));
            }

        } catch (PDOException $e) {
            return $response->withJson((["excepcion" => $e->getMessage()]));
        }
    }

    }

    class Usuario{

        public $id;
        public $correo;
        public $clave;
        public $nombre;
        public $apellido;
        public $perfil;
        public $foto;

        public function __construct($id = 0, $correo = "Sin correo", $clave = "Sin clave", $nombre = "Sin nombre", $apellido = "Sin apellido", $perfil = "Sin perfil", $foto = "Sin foto")
        {
            $this->id = $id;
            $this->correo = $correo;
            $this->clave = $clave;
            $this->nombre = $nombre;
            $this->apellido = $apellido;
            $this->perfil = $perfil;
            $this->foto = $foto;
        }

        public function ToString(){

            return $this->id . $this->correo;
        }

        public static function AltaDeUsuario($request, $response)
        {
            $parametros = $request->getParsedBody();

            $correo = $parametros['correo'];

            $clave = $parametros['clave'];

            $nombre = $parametros['nombre'];

            $apellido = $parametros['apellido'];

            $perfil = $parametros['perfil'];

            $directorio = "./fotos/" . $correo . "-" . $apellido . ".jpg";

            try {
                $usuario = 'root';
                $pass = '';
                $pdo = new PDO('mysql:host=localhost;dbname=MerceriaBD;charset=utf8', $usuario, $pass);

                $sentencia = $pdo->prepare('INSERT INTO usuarios(correo,clave,nombre,apellido,perfil,foto) VALUES (:correo,:clave,:nombre,:apellido,:perfil,:foto)');

                $retornador = $sentencia->execute(array('correo' => $correo,'clave' => $clave,'nombre' => $nombre,'apellido' => $apellido,'perfil' => $perfil,'foto' => $directorio));

                move_uploaded_file($_FILES["foto"]["tmp_name"], $directorio);

                if($retornador)
                {
                    return $response->withJson((['exito' => true]));
                }
                else
                {
                    return $response->withJson((['exito' => false]));
                }
                
            } catch (PDOException $e) {
                return $response->withJson((["excepcion" => $e->getMessage()]));
            }
        }

        public static function TraerUsuarios()
        {
            $conexion = 'mysql:host=localhost;dbname=MerceriaBD;charset=utf8';
            $usuario='root';
            $clave='';
    
            try
            {
                $arrayUsuarios = array();
    
                $pdo = new PDO($conexion, $usuario, $clave);
                
                //Preparo la sentencia.
               
                $sentencia = $pdo->prepare('SELECT * FROM usuarios');
                
                //Ejecuto la sentencia.
    
                $retornador = $sentencia->execute();
    
                while($fila = $sentencia->fetch(PDO::FETCH_ASSOC))
                {
                    ini_set('memory_limit', '-1');
    
                    $usuario = new Usuario($fila['id'],$fila['correo'], $fila['clave'], $fila['nombre'], $fila['apellido'], $fila['perfil'], $fila['foto']);
    
                    array_push($arrayUsuarios, $usuario);
    
                }
    
                var_dump($retornador);
    
                if($retornador)
                {
                    return $arrayUsuarios;
                }
                else
                {
                    return null;
                }
            }
            catch(PDOException $e)
            {
                return null;
            }
        }

        public static function ListadoDeUsuarios($request, $response)
        {
            $conexion = 'mysql:host=localhost;dbname=MerceriaBD;charset=utf8';
            $usuario='root';
            $clave='';
    
            try
            {
                $arrayUsuarios = array();
    
                $pdo = new PDO($conexion, $usuario, $clave);
                
                //Preparo la sentencia.
               
                $sentencia = $pdo->prepare('SELECT * FROM usuarios');
                
                //Ejecuto la sentencia.
    
                $retornador = $sentencia->execute();
    
                while($fila = $sentencia->fetch(PDO::FETCH_ASSOC))
                {
                    ini_set('memory_limit', '-1');
    
                    $usuario = new Usuario($fila['id'],$fila['correo'], $fila['clave'], $fila['nombre'], $fila['apellido'], $fila['perfil'], $fila['foto']);
    
                    array_push($arrayUsuarios, $usuario);
    
                }
    
                var_dump($retornador);
    
                if($retornador)
                {
                    return $response->withJson(['usuarios' => $arrayUsuarios], 200);
                }
                else
                {
                    return $response->withJson((['exito' => false]));
                }
            }
            catch(PDOException $e)
            {
                return $response->withJson((["excepcion" => $e->getMessage()]));
            }
        }

        public static function AltaDeVentas($request, $response)
        {
            $atributos = $request->getParsedBody();

            //$id = $atributos['id']; 
            $idUsuario = $atributos['id_usuario'];
            $idMedia = $atributos['id_media'];
            $cantidad =  $atributos['cantidad'];

            $conexion = 'mysql:host=localhost;dbname=MerceriaBD;charset=utf8';
            $usuario='root';
            $clave='';

            try
            {
                $pdo = new PDO($conexion, $usuario, $clave);
                
                //Preparo la sentencia.
            
                $sentencia = $pdo->prepare('INSERT INTO ventas_medias(id_usuario, id_media, cantidad) VALUES ('. $idUsuario.','.$idMedia.','.$cantidad.')');
                
                //Ejecuto la sentencia.

                $retornador = $sentencia->execute();

                var_dump($retornador);

                if($retornador)
                {
                    return $response->withJson(['status' => 200]);
                }
                else
                {
                    return $response->withJson(['status' => 504]);
                }
            }
            catch(PDOException $e)
            {
                return $response->withJson((["excepcion" => $e->getMessage()]));
            }
        }

        public static function ListadoDeVentas($request, $response)
        {
            $conexion = 'mysql:host=localhost;dbname=MerceriaBD;charset=utf8';
            $usuario='root';
            $clave='';
    
            try
            {
                $arrayVentas = array();
    
                $pdo = new PDO($conexion, $usuario, $clave);
                
                //Preparo la sentencia.
               
                $sentencia = $pdo->prepare('SELECT * FROM ventas_medias');
                
                //Ejecuto la sentencia.
    
                $retornador = $sentencia->execute();
    
                $sentencia->execute();
                while ($fila = $sentencia->fetchObject()) {
                    array_push($arrayVentas, $fila);
                }
    
                var_dump($retornador);
    
                if($retornador)
                {
                    return $response->withJson(['ventas' => $arrayVentas], 200);
                }
                else
                {
                    return $response->withJson((['exito' => false]));
                }
            }
            catch(PDOException $e)
            {
                return $response->withJson((["excepcion" => $e->getMessage()]));
            }
        }
        
    }

    class MW{

        public function EsPropietario($request, $response)
        {
            $retorno = false;

            $atributos = $request->getParsedBody();

            $arrayUsuarios = Usuario::TraerUsuarios();

            for($j = 0; $j < count($arrayUsuarios); $j++)
            {
                if($arrayUsuarios[$j] == $atributos['correo'] && $arrayUsuarios[$j+4] == 'propietario')
                {
                    return $response->withJson((['propietario' => true]));
                    $retorno = true;
                    break;
                }
            }
        
            if($retorno)
            {
                return $response->withJson((['propietario' => false]));
            }
        }
    }
?>